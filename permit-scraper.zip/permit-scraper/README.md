# Municipal records scraper

Permits, code violations, zoning changes, pre-foreclosure filings -> SQLite (history) + CSVs.

## Deploy (free)
1. Create a **private** GitHub repo, push these files.
2. (Recommended) get a free Socrata app token and add it as repo secret `SOCRATA_APP_TOKEN`.
3. Actions tab -> "scrape" -> Run workflow. Download CSVs from the run's `exports` artifact
   or from `data/exports/` in the repo. Runs weekly after that.
4. Add jurisdictions in `config/sources.yaml`. Verify dataset IDs/fields first.

Local test: `pip install -r requirements.txt && python main.py`
